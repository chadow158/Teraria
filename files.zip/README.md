# ⛏️ Terraria Clone

A browser-based 2D sandbox adventure game inspired by Terraria, built entirely with vanilla HTML5 Canvas and ES6 modules — no dependencies, no build step.

![Preview](https://img.shields.io/badge/status-playable-brightgreen)
![License](https://img.shields.io/badge/license-MIT-blue)

## 🎮 Play it

Just open `index.html` in any modern browser (Chrome, Firefox, Edge).  
> **Note:** Because of ES6 modules you need to serve it via a local server — see below.

```bash
# Python
python3 -m http.server 8080

# Node.js (npx)
npx serve .

# Then open http://localhost:8080
```

## 🕹️ Controls

| Key / Button | Action |
|---|---|
| `A` / `D` | Move left / right |
| `W` / `Space` | Jump |
| `Left Click` | Mine block / Attack enemy / Use item |
| `Right Click` | Place selected block |
| `1`–`9` | Select hotbar slot |
| `Scroll` | Cycle hotbar |
| `E` | Open / close inventory & crafting |
| `Ctrl + Scroll` | Zoom in / out |
| `Esc` | Pause menu |

## ✨ Features

### World
- **Procedural terrain** using layered Perlin noise
- **Biomes**: Forest, Desert (cacti, sand), Snow (ice, snowfall), Sky islands
- **Underground caves** carved with 3D noise
- **Ore veins**: Coal, Iron, Gold, Diamond
- **Decorations**: Trees, cacti, flowers, mushrooms, torches
- **Hell layer** at depth with Hellstone
- Full day/night cycle with sun, moon, and stars

### Gameplay
- **Mining** with progressive breaking (hardness system)
- **Placing blocks** anywhere in reach
- **Crafting system** — craft pickaxes, swords, axes, torches, chests, platforms
- **Item drops** with physics — they bounce and can be picked up
- **Inventory** — 40 slots with stackable items
- **Hotbar** — 9 quick-access slots

### Combat
- **Melee weapons** — Wood, Stone, Iron, Gold, Diamond swords
- **Enemies**: Green Slime, Zombie, Demon Eye, Skeleton, Cave Bat
- Enemy AI with pathfinding, jumping, flying
- **Damage indicators** & health bars
- Day/night spawning — more enemies at night
- **Death & respawn** system with coin drops

### Rendering
- Canvas 2D pixel-art style renderer
- **Day/night sky** — dynamic gradient, sun, moon, stars
- **Torch lighting** with glow
- **Particle effects** — dust, hits, damage
- Smooth camera tracking
- Zoomable viewport (1x–4x)

## 🗂️ Project Structure

```
terraria-clone/
├── index.html          # Entry point
├── src/
│   ├── main.js         # Game loop & orchestration
│   ├── constants.js    # All game constants, tile IDs, items, recipes
│   ├── world.js        # World generation & tile management
│   ├── player.js       # Player physics, inventory, mining
│   ├── enemies.js      # Enemy AI & spawning
│   ├── renderer.js     # Canvas 2D rendering
│   ├── hud.js          # UI: hotbar, inventory, crafting
│   ├── input.js        # Keyboard & mouse input
│   ├── particles.js    # Particle effect system
│   └── style.css       # UI styles
└── README.md
```

## 🔧 Extending the Game

The codebase is designed to be hackable:

- **Add a new tile**: Add it to `T` and `TILE_DEF` in `constants.js`, then add rendering in `renderer.js`
- **Add a new item/weapon**: Add to `ITEM`, `ITEM_DEF`, and optionally `RECIPES`
- **Add a new enemy**: Add a type to `ENEMY_TYPES` in `enemies.js`
- **New biome**: Add logic in `World._generate()` in `world.js`

## 📋 Roadmap / Ideas

- [ ] Save/load world to `localStorage`
- [ ] Multiplayer via WebRTC / WebSockets
- [ ] Boss fights (Eye of Cthulhu, etc.)
- [ ] Armor system
- [ ] Ranged weapons (bow & arrow)
- [ ] Chests with loot
- [ ] NPCs (Merchant, Guide)
- [ ] Liquid physics (water/lava flow)
- [ ] Sound effects (Web Audio API)
- [ ] Mobile touch controls

## 📄 License

MIT — do whatever you want with it.

---

*This is a fan-made clone for educational purposes. Terraria is a registered trademark of Re-Logic.*
