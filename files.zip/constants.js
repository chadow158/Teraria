// ── TILE SIZE ──────────────────────────────────────────
export const TILE = 16; // px per tile (world units)

// ── WORLD ──────────────────────────────────────────────
export const WORLD_W  = 400;  // tiles wide
export const WORLD_H  = 200;  // tiles tall
export const SEA_LEVEL = 60;  // surface y
export const CAVE_START = 80; // underground begins
export const HELL_START = 170;

// ── PHYSICS ────────────────────────────────────────────
export const GRAVITY   = 0.5;
export const JUMP_FORCE = -10;
export const MOVE_SPEED = 3.5;
export const MAX_FALL   = 18;

// ── PLAYER ─────────────────────────────────────────────
export const PLAYER_W = 14;
export const PLAYER_H = 28;
export const REACH    = 5; // tiles radius for mining/placing

// ── TILE IDs ───────────────────────────────────────────
export const T = {
  AIR:   0,
  DIRT:  1,
  GRASS: 2,
  STONE: 3,
  SAND:  4,
  WOOD:  5,
  LEAF:  6,
  WATER: 7,
  LAVA:  8,
  COAL:  9,
  IRON:  10,
  GOLD:  11,
  DIAMOND: 12,
  CHEST:  13,
  TORCH:  14,
  PLAT:   15, // platform
  CLOUD:  16,
  SNOW:   17,
  ICE:    18,
  CACTUS: 19,
  SUNFLOWER: 20,
  MUSHROOM: 21,
  HELLSTONE: 22,
};

// ── TILE DEFINITIONS ──────────────────────────────────
export const TILE_DEF = {
  [T.AIR]:      { solid: false, color: null,      label: 'Air',       hardness: 0,   drop: null },
  [T.DIRT]:     { solid: true,  color: '#7a5c3a',  label: 'Dirt',      hardness: 1,   drop: T.DIRT },
  [T.GRASS]:    { solid: true,  color: '#3a8a3a',  label: 'Grass',     hardness: 1,   drop: T.DIRT },
  [T.STONE]:    { solid: true,  color: '#888',     label: 'Stone',     hardness: 2,   drop: T.STONE },
  [T.SAND]:     { solid: true,  color: '#e0c060',  label: 'Sand',      hardness: 1,   drop: T.SAND },
  [T.WOOD]:     { solid: true,  color: '#7a5020',  label: 'Wood',      hardness: 1.5, drop: T.WOOD },
  [T.LEAF]:     { solid: false, color: '#2a7a2a',  label: 'Leaf',      hardness: 0.5, drop: null },
  [T.WATER]:    { solid: false, color: '#2060c088',label: 'Water',     hardness: 0,   drop: null },
  [T.LAVA]:     { solid: false, color: '#e04000cc',label: 'Lava',      hardness: 0,   drop: null },
  [T.COAL]:     { solid: true,  color: '#333',     label: 'Coal Ore',  hardness: 2,   drop: T.COAL },
  [T.IRON]:     { solid: true,  color: '#a07060',  label: 'Iron Ore',  hardness: 3,   drop: T.IRON },
  [T.GOLD]:     { solid: true,  color: '#e0a000',  label: 'Gold Ore',  hardness: 3,   drop: T.GOLD },
  [T.DIAMOND]:  { solid: true,  color: '#60e0e0',  label: 'Diamond',   hardness: 4,   drop: T.DIAMOND },
  [T.CHEST]:    { solid: true,  color: '#b06010',  label: 'Chest',     hardness: 1,   drop: T.CHEST },
  [T.TORCH]:    { solid: false, color: '#f0a020',  label: 'Torch',     hardness: 0.2, drop: T.TORCH },
  [T.PLAT]:     { solid: true,  color: '#9a7a4a',  label: 'Platform',  hardness: 1,   drop: T.PLAT, platform: true },
  [T.CLOUD]:    { solid: true,  color: '#ddeeff',  label: 'Cloud',     hardness: 0.5, drop: null },
  [T.SNOW]:     { solid: true,  color: '#e0eeff',  label: 'Snow',      hardness: 0.8, drop: T.SNOW },
  [T.ICE]:      { solid: true,  color: '#a0d0f0',  label: 'Ice',       hardness: 1,   drop: T.ICE },
  [T.CACTUS]:   { solid: true,  color: '#30a030',  label: 'Cactus',    hardness: 0.8, drop: T.CACTUS },
  [T.SUNFLOWER]:{ solid: false, color: '#f0d000',  label: 'Sunflower', hardness: 0.3, drop: null },
  [T.MUSHROOM]: { solid: false, color: '#e0c0a0',  label: 'Mushroom',  hardness: 0.2, drop: T.MUSHROOM },
  [T.HELLSTONE]:{ solid: true,  color: '#8a1000',  label: 'Hellstone', hardness: 5,   drop: T.HELLSTONE },
};

// ── ITEMS ──────────────────────────────────────────────
export const ITEM = {
  // tiles double as items when dropped
  // extra items:
  WOOD_SWORD:   100,
  STONE_SWORD:  101,
  IRON_SWORD:   102,
  GOLD_SWORD:   103,
  DIAMOND_SWORD:104,
  WOOD_PICK:    110,
  STONE_PICK:   111,
  IRON_PICK:    112,
  GOLD_PICK:    113,
  DIAMOND_PICK: 114,
  WOOD_AXE:     120,
  TORCH_ITEM:   T.TORCH,
  COIN_COPPER:  200,
  COIN_SILVER:  201,
  COIN_GOLD:    202,
  HEART:        210,
};

export const ITEM_DEF = {
  [ITEM.WOOD_SWORD]:   { label: 'Wood Sword',    emoji: '🗡️',  damage: 8,  speed: 25, type: 'sword' },
  [ITEM.STONE_SWORD]:  { label: 'Stone Sword',   emoji: '⚔️',  damage: 13, speed: 22, type: 'sword' },
  [ITEM.IRON_SWORD]:   { label: 'Iron Sword',    emoji: '🔪',  damage: 20, speed: 20, type: 'sword' },
  [ITEM.GOLD_SWORD]:   { label: 'Gold Sword',    emoji: '✨',  damage: 25, speed: 18, type: 'sword' },
  [ITEM.DIAMOND_SWORD]:{ label: 'Diamond Sword', emoji: '💎',  damage: 45, speed: 15, type: 'sword' },
  [ITEM.WOOD_PICK]:    { label: 'Wood Pickaxe',  emoji: '⛏️',  power: 40,  speed: 15, type: 'pick' },
  [ITEM.STONE_PICK]:   { label: 'Stone Pickaxe', emoji: '⛏️',  power: 55,  speed: 12, type: 'pick' },
  [ITEM.IRON_PICK]:    { label: 'Iron Pickaxe',  emoji: '⛏️',  power: 70,  speed: 10, type: 'pick' },
  [ITEM.GOLD_PICK]:    { label: 'Gold Pickaxe',  emoji: '⛏️',  power: 80,  speed: 8,  type: 'pick' },
  [ITEM.DIAMOND_PICK]: { label: 'Diamond Pick',  emoji: '⛏️',  power: 100, speed: 6,  type: 'pick' },
  [ITEM.WOOD_AXE]:     { label: 'Wood Axe',      emoji: '🪓',  power: 45,  speed: 14, type: 'axe' },
  [ITEM.TORCH_ITEM]:   { label: 'Torch',         emoji: '🔦',  type: 'placeable', places: T.TORCH },
  [ITEM.COIN_COPPER]:  { label: 'Copper Coin',   emoji: '🟤',  value: 1 },
  [ITEM.COIN_SILVER]:  { label: 'Silver Coin',   emoji: '⚪',  value: 100 },
  [ITEM.COIN_GOLD]:    { label: 'Gold Coin',     emoji: '🟡',  value: 10000 },
  [ITEM.HEART]:        { label: 'Life Crystal',  emoji: '💗',  maxHp: 20 },
  // Tiles as items
  [T.DIRT]:     { label: 'Dirt',      emoji: '🟫', type: 'block', places: T.DIRT },
  [T.STONE]:    { label: 'Stone',     emoji: '⬜', type: 'block', places: T.STONE },
  [T.SAND]:     { label: 'Sand',      emoji: '🟨', type: 'block', places: T.SAND },
  [T.WOOD]:     { label: 'Wood',      emoji: '🪵', type: 'block', places: T.WOOD },
  [T.COAL]:     { label: 'Coal',      emoji: '⬛', type: 'material' },
  [T.IRON]:     { label: 'Iron Ore',  emoji: '🔴', type: 'material' },
  [T.GOLD]:     { label: 'Gold Ore',  emoji: '🟡', type: 'material' },
  [T.DIAMOND]:  { label: 'Diamond',   emoji: '💎', type: 'material' },
  [T.SNOW]:     { label: 'Snow',      emoji: '❄️', type: 'block', places: T.SNOW },
  [T.ICE]:      { label: 'Ice',       emoji: '🧊', type: 'block', places: T.ICE },
  [T.CACTUS]:   { label: 'Cactus',    emoji: '🌵', type: 'block', places: T.CACTUS },
  [T.HELLSTONE]:{ label: 'Hellstone', emoji: '🔥', type: 'material' },
  [T.CHEST]:    { label: 'Chest',     emoji: '📦', type: 'block', places: T.CHEST },
  [T.PLAT]:     { label: 'Platform',  emoji: '🟫', type: 'block', places: T.PLAT },
};

// ── RECIPES ────────────────────────────────────────────
// { result, count, ingredients: { itemId: qty } }
export const RECIPES = [
  { result: ITEM.WOOD_PICK,    count: 1, ingredients: { [T.WOOD]: 10 } },
  { result: ITEM.WOOD_SWORD,   count: 1, ingredients: { [T.WOOD]: 8 } },
  { result: ITEM.WOOD_AXE,     count: 1, ingredients: { [T.WOOD]: 9 } },
  { result: ITEM.STONE_PICK,   count: 1, ingredients: { [T.WOOD]: 4, [T.STONE]: 15 } },
  { result: ITEM.STONE_SWORD,  count: 1, ingredients: { [T.WOOD]: 2, [T.STONE]: 10 } },
  { result: ITEM.IRON_PICK,    count: 1, ingredients: { [T.WOOD]: 4, [T.IRON]: 15 } },
  { result: ITEM.IRON_SWORD,   count: 1, ingredients: { [T.WOOD]: 2, [T.IRON]: 10 } },
  { result: ITEM.GOLD_PICK,    count: 1, ingredients: { [T.WOOD]: 4, [T.GOLD]: 15 } },
  { result: ITEM.GOLD_SWORD,   count: 1, ingredients: { [T.WOOD]: 2, [T.GOLD]: 10 } },
  { result: ITEM.DIAMOND_PICK, count: 1, ingredients: { [T.WOOD]: 4, [T.DIAMOND]: 12 } },
  { result: ITEM.DIAMOND_SWORD,count: 1, ingredients: { [T.WOOD]: 2, [T.DIAMOND]: 8 } },
  { result: T.TORCH,           count: 4, ingredients: { [T.WOOD]: 1, [T.COAL]: 1 } },
  { result: T.PLAT,            count: 4, ingredients: { [T.WOOD]: 2 } },
  { result: T.CHEST,           count: 1, ingredients: { [T.WOOD]: 8, [T.IRON]: 2 } },
];
