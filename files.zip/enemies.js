import { TILE, T, GRAVITY, WORLD_W, WORLD_H } from './constants.js';

const ENEMY_TYPES = {
  slime: {
    label: 'Green Slime', emoji: '🟢', w: 20, h: 16,
    hp: 25, maxHp: 25, damage: 8, speed: 1.2, jumpForce: -7,
    xp: 5, coin: 1,
    color: '#40a040', eyeColor: '#fff',
  },
  zombie: {
    label: 'Zombie', emoji: '🧟', w: 14, h: 28,
    hp: 45, maxHp: 45, damage: 12, speed: 1.0, jumpForce: -8,
    xp: 10, coin: 3,
    color: '#508050', eyeColor: '#f00',
  },
  eye: {
    label: 'Demon Eye', emoji: '👁️', w: 20, h: 16,
    hp: 35, maxHp: 35, damage: 10, speed: 2.0, jumpForce: 0,
    xp: 8, coin: 2, flying: true,
    color: '#800020', eyeColor: '#ff4040',
  },
  skeleton: {
    label: 'Skeleton', emoji: '💀', w: 14, h: 28,
    hp: 60, maxHp: 60, damage: 18, speed: 1.5, jumpForce: -9,
    xp: 15, coin: 5,
    color: '#e8e8e8', eyeColor: '#000',
  },
  bat: {
    label: 'Cave Bat', emoji: '🦇', w: 18, h: 12,
    hp: 20, maxHp: 20, damage: 7, speed: 2.5, jumpForce: 0,
    xp: 6, coin: 1, flying: true,
    color: '#505070', eyeColor: '#f00',
  },
};

export class Enemy {
  constructor(type, x, y, world) {
    this.type   = type;
    const def   = ENEMY_TYPES[type];
    Object.assign(this, def);
    this.hp     = def.hp;
    this.x      = x * TILE;
    this.y      = y * TILE - def.h;
    this.vx     = 0; this.vy = 0;
    this.onGround = false;
    this.world  = world;
    this.dir    = Math.random() < .5 ? 1 : -1;
    this.attackCd = 0;
    this.aiTimer  = 0;
    this.hitFlash = 0;
    this.dead     = false;
  }

  get cx() { return this.x + this.w / 2; }
  get cy() { return this.y + this.h / 2; }

  update(player) {
    if (this.dead) return;
    this.attackCd  = Math.max(0, this.attackCd - 1);
    this.hitFlash  = Math.max(0, this.hitFlash - 1);
    this.aiTimer++;

    const dx = player.cx - this.cx;
    const dy = player.cy - this.cy;
    const dist = Math.hypot(dx, dy);

    // ── Flying enemies ─────────────────────────────
    if (this.flying) {
      this.vx += (dx / dist) * 0.3 * this.speed;
      this.vy += (dy / dist) * 0.3 * this.speed;
      const spd = Math.hypot(this.vx, this.vy);
      if (spd > this.speed * 2) { this.vx *= this.speed * 2 / spd; this.vy *= this.speed * 2 / spd; }
    } else {
      // ── Ground enemies ─────────────────────────────
      if (dist < TILE * 20) {
        this.dir = dx > 0 ? 1 : -1;
        this.vx = this.dir * this.speed;
        // Jump over obstacles
        if (this.onGround && this.aiTimer % 20 === 0) {
          const nx = Math.floor((this.cx + this.dir * this.w) / TILE);
          const ny = Math.floor((this.y + this.h) / TILE);
          if (this.world.get(nx, ny) !== T.AIR) {
            this.vy = this.jumpForce; this.onGround = false;
          }
        }
      } else {
        this.vx *= 0.8;
      }
      this.vy = Math.min(this.vy + GRAVITY, 12);
    }

    this.x += this.vx; this._resolveX();
    this.y += this.vy; this._resolveY();

    // Attack player
    if (dist < TILE * 1.5 && this.attackCd === 0) {
      player.hurt(this.damage);
      this.attackCd = 60;
    }
  }

  _resolveX() {
    const y0 = Math.floor(this.y / TILE), y1 = Math.floor((this.y + this.h - 1) / TILE);
    const xE = this.vx > 0 ? Math.floor((this.x + this.w - 1) / TILE) : Math.floor(this.x / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      const t = this.world.get(xE, ty);
      if (TILE_DEF_SOLID(t)) {
        if (this.vx > 0) this.x = xE * TILE - this.w;
        else this.x = (xE + 1) * TILE;
        this.vx = 0; break;
      }
    }
  }
  _resolveY() {
    this.onGround = false;
    const x0 = Math.floor(this.x / TILE), x1 = Math.floor((this.x + this.w - 1) / TILE);
    const yE = this.vy > 0 ? Math.floor((this.y + this.h - 1) / TILE) : Math.floor(this.y / TILE);
    for (let tx = x0; tx <= x1; tx++) {
      const t = this.world.get(tx, yE);
      if (TILE_DEF_SOLID(t)) {
        if (this.vy > 0) { this.y = yE * TILE - this.h; this.onGround = true; }
        else this.y = (yE + 1) * TILE;
        this.vy = 0; break;
      }
    }
  }

  hit(dmg) {
    this.hp -= dmg;
    this.hitFlash = 8;
    if (this.hp <= 0) { this.dead = true; return true; }
    return false;
  }
}

function TILE_DEF_SOLID(t) {
  const solids = new Set([T.DIRT, T.GRASS, T.STONE, T.SAND, T.WOOD,
    T.COAL, T.IRON, T.GOLD, T.DIAMOND, T.CHEST, T.PLAT,
    T.CLOUD, T.SNOW, T.ICE, T.CACTUS, T.HELLSTONE]);
  return solids.has(t);
}

// ── SPAWNER ─────────────────────────────────────────────
export class EnemyManager {
  constructor(world) {
    this.world   = world;
    this.enemies = [];
    this.spawnTimer = 0;
  }

  update(player, isNight) {
    this.spawnTimer++;
    const interval = isNight ? 180 : 360;
    if (this.spawnTimer >= interval && this.enemies.length < 30) {
      this.spawnTimer = 0;
      this._trySpawn(player, isNight);
    }

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.update(player);
      if (e.dead) {
        // Drop coins / xp
        this.world.dropItem(Math.floor(e.cx / TILE), Math.floor(e.cy / TILE),
          200, e.coin); // COIN_COPPER
        this.enemies.splice(i, 1);
      }
    }

    // Despawn far enemies
    this.enemies = this.enemies.filter(e => {
      return Math.hypot(e.cx - player.cx, e.cy - player.cy) < TILE * 120;
    });
  }

  _trySpawn(player, isNight) {
    const angle = Math.random() * Math.PI * 2;
    const dist  = TILE * (50 + Math.random() * 30);
    const sx = player.tileX + Math.cos(angle) * dist / TILE | 0;
    const sy = player.tileY + Math.sin(angle) * dist / TILE | 0;
    if (sx < 0 || sx >= WORLD_W || sy < 0 || sy >= WORLD_H) return;

    // Find ground
    let gy = sy;
    for (; gy < WORLD_H - 1; gy++) {
      if (this.world.get(sx, gy) === T.AIR && this.world.get(sx, gy + 1) !== T.AIR) break;
    }
    if (gy >= WORLD_H - 1) return;

    // Pick type based on depth & time
    const depth = gy;
    let type;
    if (depth > 120) type = Math.random() < .5 ? 'skeleton' : 'bat';
    else if (isNight) type = Math.random() < .6 ? 'zombie' : (Math.random() < .5 ? 'eye' : 'slime');
    else type = Math.random() < .7 ? 'slime' : 'bat';

    this.enemies.push(new Enemy(type, sx, gy, this.world));
  }

  // Melee attack from player
  meleeAttack(player, damage) {
    const reach = TILE * 4;
    for (const e of this.enemies) {
      const dist = Math.hypot(e.cx - player.cx, e.cy - player.cy);
      if (dist < reach) e.hit(damage);
    }
  }
}
