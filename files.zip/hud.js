import { ITEM_DEF, TILE_DEF, T, RECIPES } from './constants.js';

export class HUD {
  constructor(player) {
    this.player = player;
    this.hotbarEl    = document.getElementById('hotbar');
    this.hpFill      = document.getElementById('hp-fill');
    this.mpFill      = document.getElementById('mp-fill');
    this.hpLabel     = document.getElementById('hp-label');
    this.mpLabel     = document.getElementById('mp-label');
    this.invScreen   = document.getElementById('inventory-screen');
    this.invGrid     = document.getElementById('inventory-grid');
    this.craftList   = document.getElementById('crafting-list');
    this.tooltip     = document.getElementById('tooltip');
    this.invOpen     = false;

    document.getElementById('close-inv').onclick = () => this.closeInventory();
    this._buildHotbar();
  }

  _buildHotbar() {
    this.hotbarEl.innerHTML = '';
    for (let i = 0; i < 9; i++) {
      const slot = document.createElement('div');
      slot.className = 'hotbar-slot';
      slot.dataset.idx = i;
      slot.innerHTML = `<span class="slot-label">${i+1}</span>`;
      slot.onclick = () => { this.player.selectedSlot = i; this.update(); };
      this.hotbarEl.appendChild(slot);
    }
  }

  update() {
    const p = this.player;

    // HP / MP
    const hpPct = (p.hp / p.maxHp) * 100;
    const mpPct = (p.mp / p.maxMp) * 100;
    this.hpFill.style.width = hpPct + '%';
    this.mpFill.style.width = mpPct + '%';
    this.hpLabel.textContent = `❤ ${Math.ceil(p.hp)}/${p.maxHp}`;
    this.mpLabel.textContent = `✦ ${p.mp}/${p.maxMp}`;

    // Hotbar
    const slots = this.hotbarEl.querySelectorAll('.hotbar-slot');
    slots.forEach((sl, i) => {
      sl.classList.toggle('active', i === p.selectedSlot);
      const item = p.inv[i];
      sl.innerHTML = `<span class="slot-label">${i+1}</span>`;
      if (item) {
        const def = ITEM_DEF[item.item];
        const em  = def ? (def.emoji || '?') : '?';
        const lbl = def ? def.label : '?';
        sl.innerHTML += `<span style="font-size:1.3rem">${em}</span>`;
        if (item.qty > 1) sl.innerHTML += `<span class="slot-count">${item.qty}</span>`;
        sl.querySelector('.slot-label').textContent = lbl;
      }
    });
  }

  openInventory() {
    this.invOpen = true;
    this.invScreen.style.display = 'flex';
    this._renderInventory();
    this._renderCrafting();
  }
  closeInventory() {
    this.invOpen = false;
    this.invScreen.style.display = 'none';
  }
  toggleInventory() {
    this.invOpen ? this.closeInventory() : this.openInventory();
  }

  _renderInventory() {
    this.invGrid.innerHTML = '';
    for (let i = 0; i < 40; i++) {
      const item = this.player.inv[i];
      const slot = document.createElement('div');
      slot.className = 'inv-slot';
      if (item) {
        const def = ITEM_DEF[item.item];
        const em  = def ? (def.emoji || '?') : '?';
        slot.innerHTML = `<span style="font-size:1.3rem">${em}</span>`;
        if (item.qty > 1) slot.innerHTML += `<span class="slot-count">${item.qty}</span>`;
        slot.title = def ? def.label : '?';
        slot.onclick = () => {
          // select into hotbar if slot < 9 action
          this.player.selectedSlot = i < 9 ? i : this.player.selectedSlot;
          this.closeInventory();
        };
      }
      this.invGrid.appendChild(slot);
    }
  }

  _renderCrafting() {
    this.craftList.innerHTML = '';
    for (const recipe of RECIPES) {
      const can   = this.player.canCraft(recipe);
      const def   = ITEM_DEF[recipe.result];
      const label = def ? def.label : `Item ${recipe.result}`;
      const em    = def ? (def.emoji || '') : '';
      const ingr  = Object.entries(recipe.ingredients)
        .map(([id, qty]) => {
          const d = ITEM_DEF[Number(id)];
          return `${d ? d.label : id} x${qty}`;
        }).join(', ');

      const btn = document.createElement('button');
      btn.className = 'craft-btn' + (can ? '' : ' unavailable');
      btn.innerHTML = `${em} ${label} x${recipe.count}<br><small style="color:#888">${ingr}</small>`;
      btn.disabled = !can;
      btn.onclick = () => {
        if (this.player.craft(recipe)) {
          this._renderInventory();
          this._renderCrafting();
          this.update();
        }
      };
      this.craftList.appendChild(btn);
    }
  }

  setTooltip(text) {
    this.tooltip.textContent = text || '';
  }
}
