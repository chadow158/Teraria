export class Input {
  constructor(canvas) {
    this.keys   = {};
    this.mouse  = { x: 0, y: 0, left: false, right: false };
    this.scroll = 0;
    this._callbacks = {};

    window.addEventListener('keydown', e => {
      this.keys[e.code] = true;
      this._emit('keydown', e);
    });
    window.addEventListener('keyup', e => {
      this.keys[e.code] = false;
    });
    canvas.addEventListener('mousemove', e => {
      const r = canvas.getBoundingClientRect();
      this.mouse.x = e.clientX - r.left;
      this.mouse.y = e.clientY - r.top;
    });
    canvas.addEventListener('mousedown', e => {
      if (e.button === 0) this.mouse.left  = true;
      if (e.button === 2) this.mouse.right = true;
      e.preventDefault();
    });
    canvas.addEventListener('mouseup', e => {
      if (e.button === 0) this.mouse.left  = false;
      if (e.button === 2) this.mouse.right = false;
    });
    canvas.addEventListener('wheel', e => {
      this.scroll = e.deltaY > 0 ? 1 : -1;
      this._emit('scroll', this.scroll);
      this.scroll = 0;
    });
    canvas.addEventListener('contextmenu', e => e.preventDefault());
  }

  on(event, fn) {
    this._callbacks[event] = this._callbacks[event] || [];
    this._callbacks[event].push(fn);
  }
  _emit(event, data) {
    (this._callbacks[event] || []).forEach(fn => fn(data));
  }

  get left()  { return this.keys['KeyA'] || this.keys['ArrowLeft']; }
  get right() { return this.keys['KeyD'] || this.keys['ArrowRight']; }
  get jump()  { return this.keys['KeyW'] || this.keys['Space'] || this.keys['ArrowUp']; }
  get mouseLeft()  { return this.mouse.left; }
  get mouseRight() { return this.mouse.right; }
}
