import { World }          from './world.js';
import { Player }         from './player.js';
import { Renderer }       from './renderer.js';
import { EnemyManager }   from './enemies.js';
import { HUD }            from './hud.js';
import { Input }          from './input.js';
import { ParticleSystem } from './particles.js';
import { TILE, ITEM_DEF, TILE_DEF }  from './constants.js';

// ── DOM refs ──────────────────────────────────────────
const menuScreen   = document.getElementById('menu-screen');
const gameContainer= document.getElementById('game-container');
const btnPlay      = document.getElementById('btn-play');
const pauseScreen  = document.getElementById('pause-screen');
const deathScreen  = document.getElementById('death-screen');
const btnResume    = document.getElementById('btn-resume');
const btnMenu      = document.getElementById('btn-menu');
const btnRespawn   = document.getElementById('btn-respawn');
const canvas       = document.getElementById('gameCanvas');

let game = null;

btnPlay.onclick = () => {
  menuScreen.style.display    = 'none';
  gameContainer.style.display = 'block';
  game = new Game();
  game.start();
};
btnResume.onclick = () => game && game.resume();
btnMenu.onclick   = () => {
  game && game.stop();
  pauseScreen.style.display = 'none';
  gameContainer.style.display = 'none';
  menuScreen.style.display    = 'flex';
};
btnRespawn.onclick = () => game && game.respawnPlayer();

// ─────────────────────────────────────────────────────
class Game {
  constructor() {
    this.world    = new World();
    this.player   = new Player(this.world);
    this.renderer = new Renderer(canvas, this.world);
    this.enemies  = new EnemyManager(this.world);
    this.input    = new Input(canvas);
    this.hud      = new HUD(this.player);
    this.particles= new ParticleSystem();

    this.paused   = false;
    this.running  = false;
    this.raf      = null;

    // Day/night: 0=midnight,0.5=noon,1=midnight
    this.timeOfDay = 0.3; // start at morning
    this.dayLength = 60 * 60 * 10; // 10 minutes per day in frames

    this._setupInput();
    this.hud.update();
  }

  _setupInput() {
    const inp = this.input;

    inp.on('keydown', e => {
      if (e.code === 'Escape') {
        if (this.hud.invOpen) { this.hud.closeInventory(); return; }
        this.paused ? this.resume() : this.pause();
      }
      if (e.code === 'KeyE') this.hud.toggleInventory();

      // Hotbar 1-9
      if (e.code.startsWith('Digit')) {
        const n = parseInt(e.code[5]) - 1;
        if (n >= 0 && n < 9) { this.player.selectedSlot = n; this.hud.update(); }
      }
    });

    inp.on('scroll', delta => {
      this.player.selectedSlot = (this.player.selectedSlot + delta + 9) % 9;
      this.hud.update();
    });

    // Zoom
    window.addEventListener('wheel', e => {
      if (e.ctrlKey) {
        e.preventDefault();
        this.renderer.zoom = Math.max(1, Math.min(4, this.renderer.zoom - e.deltaY * 0.003));
      }
    }, { passive: false });
  }

  start() {
    this.running = true;
    this._loop();
  }

  stop() {
    this.running = false;
    if (this.raf) cancelAnimationFrame(this.raf);
  }

  pause() {
    this.paused = true;
    pauseScreen.style.display = 'flex';
  }

  resume() {
    this.paused = false;
    pauseScreen.style.display = 'none';
  }

  respawnPlayer() {
    this.player.respawn();
    deathScreen.style.display = 'none';
  }

  _loop() {
    if (!this.running) return;
    this.raf = requestAnimationFrame(() => this._loop());
    if (this.paused || this.hud.invOpen) return;

    this._update();
    this._render();
  }

  _update() {
    const p   = this.player;
    const inp = this.input;

    // Time
    this.timeOfDay = (this.timeOfDay + 1 / this.dayLength) % 1;
    const isNight  = this.timeOfDay > 0.75 || this.timeOfDay < 0.25;

    // Mouse world pos
    const mw = this.renderer.screenToWorld(inp.mouse.x, inp.mouse.y);

    // Player
    const before = { hp: p.hp };
    p.update(inp, mw);

    // Particles on hit
    if (p.hp < before.hp) {
      this.particles.emit(p.cx, p.cy, '#ff4040', 6, 3);
    }

    // Mining particles
    if (p.miningTile && p.miningProgress > 0) {
      if (Math.random() < 0.3) {
        this.particles.emit(
          p.miningTile.tx * TILE + TILE / 2,
          p.miningTile.ty * TILE + TILE / 2,
          '#aaa', 2, 1
        );
      }
    }

    // World drops
    this.world.updateDrops(1);

    // Enemies
    this.enemies.update(p, isNight);

    // Attack enemies with sword
    const sel = p.selectedItem();
    if (sel && inp.mouseLeft) {
      const def = ITEM_DEF[sel.item];
      if (def && def.type === 'sword' && p.attackCooldown === def.speed - 1) {
        this.enemies.meleeAttack(p, def.damage);
        this.particles.emit(p.cx + p.dir * TILE * 2, p.cy, '#ff8040', 4, 4);
      }
    }

    // Particles
    this.particles.update();

    // Camera
    this.renderer.trackPlayer(p);

    // HUD
    this.hud.update();

    // Tooltip: selected item
    const item = p.selectedItem();
    if (item) {
      const d = ITEM_DEF[item.item];
      this.hud.setTooltip(d ? d.label : '');
    } else {
      this.hud.setTooltip('');
    }

    // Death
    if (p.isDead()) {
      deathScreen.style.display = 'flex';
      this.paused = true;
    }
  }

  _render() {
    const p = this.player;
    this.renderer.draw(
      p,
      this.enemies.enemies,
      this.particles.particles,
      this.timeOfDay,
      p.miningProgress,
      p.miningTile,
      this.input.mouse
    );
  }
}
