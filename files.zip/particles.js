export class ParticleSystem {
  constructor() {
    this.particles = [];
  }

  emit(x, y, color, count = 5, speed = 2) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd   = speed * (0.5 + Math.random());
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        color,
        size: 2 + Math.random() * 3,
        life: 1, maxLife: 1,
        decay: 0.02 + Math.random() * 0.03,
      });
    }
  }

  update() {
    for (const p of this.particles) {
      p.x += p.vx; p.y += p.vy;
      p.vy += 0.1; // gravity
      p.life -= p.decay;
    }
    this.particles = this.particles.filter(p => p.life > 0);
  }
}
