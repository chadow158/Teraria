import {
  TILE, GRAVITY, JUMP_FORCE, MOVE_SPEED, MAX_FALL,
  PLAYER_W, PLAYER_H, REACH, T, TILE_DEF, ITEM, ITEM_DEF, RECIPES
} from './constants.js';

export class Player {
  constructor(world) {
    this.world = world;
    const sx = world.spawnX(), sy = world.spawnY();
    this.x = sx * TILE - PLAYER_W / 2;
    this.y = sy * TILE - PLAYER_H;
    this.vx = 0; this.vy = 0;
    this.onGround = false;
    this.dir = 1; // 1=right, -1=left
    this.hp = 100; this.maxHp = 100;
    this.mp = 20;  this.maxMp = 20;

    // Inventory: 40 slots, each { item, qty } or null
    this.inv = Array(40).fill(null);
    this.hotbar = 9; // hotbar = slots 0-8
    this.selectedSlot = 0;

    // Give starter items
    this.addItem(ITEM.WOOD_PICK, 1);
    this.addItem(ITEM.WOOD_SWORD, 1);
    this.addItem(T.TORCH, 10);
    this.addItem(T.DIRT, 20);

    // Mining
    this.miningTile = null; // {tx, ty}
    this.miningProgress = 0;
    this.attackCooldown = 0;

    // Respawn
    this.spawnX = sx; this.spawnY = sy;

    // Coins
    this.coins = 0;
  }

  get tileX() { return Math.floor((this.x + PLAYER_W / 2) / TILE); }
  get tileY() { return Math.floor((this.y + PLAYER_H / 2) / TILE); }
  get cx()    { return this.x + PLAYER_W / 2; }
  get cy()    { return this.y + PLAYER_H / 2; }

  selectedItem() {
    return this.inv[this.selectedSlot];
  }

  addItem(itemId, qty = 1) {
    // stack
    for (let i = 0; i < this.inv.length; i++) {
      if (this.inv[i] && this.inv[i].item === itemId && this.inv[i].qty < 999) {
        const take = Math.min(qty, 999 - this.inv[i].qty);
        this.inv[i].qty += take;
        qty -= take;
        if (qty <= 0) return true;
      }
    }
    // new slot
    for (let i = 0; i < this.inv.length; i++) {
      if (!this.inv[i]) {
        this.inv[i] = { item: itemId, qty };
        return true;
      }
    }
    return false;
  }

  removeItem(itemId, qty = 1) {
    for (let i = 0; i < this.inv.length; i++) {
      if (this.inv[i] && this.inv[i].item === itemId) {
        if (this.inv[i].qty > qty) { this.inv[i].qty -= qty; return true; }
        if (this.inv[i].qty === qty) { this.inv[i] = null; return true; }
        qty -= this.inv[i].qty; this.inv[i] = null;
      }
    }
    return qty === 0;
  }

  countItem(itemId) {
    let n = 0;
    for (const s of this.inv) if (s && s.item === itemId) n += s.qty;
    return n;
  }

  canCraft(recipe) {
    for (const [id, qty] of Object.entries(recipe.ingredients)) {
      if (this.countItem(Number(id)) < qty) return false;
    }
    return true;
  }

  craft(recipe) {
    if (!this.canCraft(recipe)) return false;
    for (const [id, qty] of Object.entries(recipe.ingredients)) {
      this.removeItem(Number(id), qty);
    }
    this.addItem(recipe.result, recipe.count);
    return true;
  }

  // ── PHYSICS ───────────────────────────────────────────
  update(input, mouseWorld) {
    if (this.attackCooldown > 0) this.attackCooldown--;

    // Movement
    if (input.left)  { this.vx = -MOVE_SPEED; this.dir = -1; }
    else if (input.right) { this.vx = MOVE_SPEED; this.dir = 1; }
    else this.vx *= 0.7;

    // Jump
    if ((input.jump) && this.onGround) {
      this.vy = JUMP_FORCE;
      this.onGround = false;
    }

    // Gravity
    this.vy = Math.min(this.vy + GRAVITY, MAX_FALL);

    this._moveAndCollide();

    // Mining / using
    if (input.mouseLeft) this._useTool(mouseWorld, false);
    else { this.miningTile = null; this.miningProgress = 0; }

    if (input.mouseRight) this._placeBlock(mouseWorld);

    // Pick up drops
    for (let i = this.world.drops.length - 1; i >= 0; i--) {
      const d = this.world.drops[i];
      if (d.age < 30) continue;
      const dist = Math.hypot(d.x - this.cx, d.y - this.cy);
      if (dist < TILE * 2.5) {
        if (this.addItem(d.item, d.qty)) {
          this.world.drops.splice(i, 1);
        }
      }
    }

    // Environmental damage
    const tx = this.tileX, ty = this.tileY;
    const foot = this.world.get(tx, ty + 1);
    if (foot === T.LAVA) this.hurt(2);

    // Regen
    if (this.hp < this.maxHp && Math.random() < 0.002) this.hp = Math.min(this.hp + 1, this.maxHp);
  }

  _moveAndCollide() {
    this.x += this.vx;
    this._resolveAxis('x');
    this.y += this.vy;
    this.onGround = false;
    this._resolveAxis('y');
  }

  _resolveAxis(axis) {
    const x0 = Math.floor(this.x / TILE);
    const x1 = Math.floor((this.x + PLAYER_W - 1) / TILE);
    const y0 = Math.floor(this.y / TILE);
    const y1 = Math.floor((this.y + PLAYER_H - 1) / TILE);

    for (let tx = x0; tx <= x1; tx++) {
      for (let ty = y0; ty <= y1; ty++) {
        const t = this.world.get(tx, ty);
        const def = TILE_DEF[t];
        if (!def || !def.solid) continue;
        if (def.platform) {
          // only collide from above
          if (axis === 'y' && this.vy >= 0) {
            const playerBottom = this.y + PLAYER_H;
            const tileTop = ty * TILE;
            if (playerBottom > tileTop && playerBottom < tileTop + TILE * 0.6) {
              this.y = tileTop - PLAYER_H;
              this.vy = 0; this.onGround = true;
            }
          }
          continue;
        }
        // solid block
        if (axis === 'x') {
          if (this.vx > 0) this.x = tx * TILE - PLAYER_W;
          else if (this.vx < 0) this.x = (tx + 1) * TILE;
          this.vx = 0;
        } else {
          if (this.vy > 0) { this.y = ty * TILE - PLAYER_H; this.onGround = true; }
          else             { this.y = (ty + 1) * TILE; }
          this.vy = 0;
        }
      }
    }
  }

  // ── TOOL USE ─────────────────────────────────────────
  _useTool(mw, isRight) {
    const tx = Math.floor(mw.x / TILE);
    const ty = Math.floor(mw.y / TILE);
    if (!this._inReach(tx, ty)) { this.miningTile = null; this.miningProgress = 0; return; }

    const slot = this.selectedItem();
    const def  = slot ? ITEM_DEF[slot.item] : null;

    // Sword — attack
    if (def && def.type === 'sword') {
      if (this.attackCooldown === 0) {
        this.attackCooldown = def.speed;
        return { attack: true, damage: def.damage, x: this.cx, y: this.cy };
      }
      return;
    }

    // Mining
    const tile = this.world.get(tx, ty);
    if (tile === T.AIR) { this.miningTile = null; this.miningProgress = 0; return; }

    const tdex = TILE_DEF[tile];
    if (!tdex || tdex.hardness === 0) return;

    // reset if changed target
    if (!this.miningTile || this.miningTile.tx !== tx || this.miningTile.ty !== ty) {
      this.miningTile = { tx, ty };
      this.miningProgress = 0;
    }

    // pick power
    let power = 20; // fist
    let speed = 20;
    if (def && def.type === 'pick') { power = def.power; speed = def.speed; }
    else if (def && def.type === 'axe' && (tile === T.WOOD || tile === T.LEAF)) {
      power = def.power; speed = def.speed;
    }

    this.miningProgress += power / (tdex.hardness * 60);
    if (this.miningProgress >= 1) {
      // break tile
      const drop = tdex.drop;
      if (drop) this.world.dropItem(tx, ty, drop, 1);
      this.world.set(tx, ty, T.AIR);
      this.miningTile = null; this.miningProgress = 0;
    }
  }

  _placeBlock(mw) {
    if (this.attackCooldown > 5) return;
    const tx = Math.floor(mw.x / TILE);
    const ty = Math.floor(mw.y / TILE);
    if (!this._inReach(tx, ty)) return;
    if (this.world.get(tx, ty) !== T.AIR) return;
    // make sure not overlapping player
    const px0 = Math.floor(this.x / TILE), px1 = Math.floor((this.x + PLAYER_W) / TILE);
    const py0 = Math.floor(this.y / TILE), py1 = Math.floor((this.y + PLAYER_H) / TILE);
    if (tx >= px0 && tx <= px1 && ty >= py0 && ty <= py1) return;

    const slot = this.selectedItem();
    if (!slot) return;
    const def = ITEM_DEF[slot.item];
    if (!def || (def.type !== 'block' && def.type !== 'placeable')) return;

    const places = def.places;
    if (places === undefined) return;

    this.world.set(tx, ty, places);
    this.removeItem(slot.item, 1);
    this.attackCooldown = 10;
  }

  _inReach(tx, ty) {
    const px = this.cx / TILE, py = this.cy / TILE;
    return Math.hypot(tx - px, ty - py) <= REACH;
  }

  hurt(dmg) {
    this.hp -= dmg;
    if (this.hp < 0) this.hp = 0;
  }

  isDead() { return this.hp <= 0; }

  respawn() {
    this.x = this.spawnX * TILE - PLAYER_W / 2;
    this.y = this.spawnY * TILE - PLAYER_H;
    this.hp = this.maxHp; this.vx = 0; this.vy = 0;
    // drop coins on death
    this.world.dropItem(this.tileX, this.tileY, ITEM.COIN_COPPER, Math.max(1, this.coins));
    this.coins = 0;
  }
}
