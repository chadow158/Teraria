import { TILE, T, TILE_DEF, WORLD_W, WORLD_H, SEA_LEVEL, HELL_START, ITEM_DEF } from './constants.js';

const SKY_COLORS = {
  day:   ['#4a90d9', '#87ceeb'],
  dawn:  ['#ff7043', '#ffb74d'],
  dusk:  ['#7b1fa2', '#ff6f00'],
  night: ['#0a0a2e', '#1a1a3e'],
};

export class Renderer {
  constructor(canvas, world) {
    this.canvas  = canvas;
    this.ctx     = canvas.getContext('2d');
    this.world   = world;
    this.camX    = 0; this.camY = 0;
    this.zoom    = 2.0;
    this.tileCache = {};
    this._resize();
    window.addEventListener('resize', () => this._resize());
  }

  _resize() {
    this.canvas.width  = window.innerWidth;
    this.canvas.height = window.innerHeight;
    this.W = this.canvas.width;
    this.H = this.canvas.height;
  }

  // Center camera on player
  trackPlayer(player) {
    const ts = TILE * this.zoom;
    this.camX = player.cx * this.zoom - this.W / 2;
    this.camY = player.cy * this.zoom - this.H / 2;
  }

  worldToScreen(wx, wy) {
    return { sx: wx * this.zoom - this.camX, sy: wy * this.zoom - this.camY };
  }
  screenToWorld(sx, sy) {
    return { wx: (sx + this.camX) / this.zoom, wy: (sy + this.camY) / this.zoom };
  }

  draw(player, enemies, particles, timeOfDay, miningProgress, miningTile, mouseScreen) {
    const ctx = this.ctx;
    const ts  = TILE * this.zoom;

    // ── Sky ─────────────────────────────────────────
    ctx.save();
    const sky = this._skyGradient(timeOfDay);
    const grad = ctx.createLinearGradient(0, 0, 0, this.H);
    grad.addColorStop(0, sky[0]);
    grad.addColorStop(1, sky[1]);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, this.W, this.H);

    // Stars at night
    if (timeOfDay > 0.75 || timeOfDay < 0.25) {
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      const alpha = timeOfDay > 0.75 ? (timeOfDay - 0.75) / 0.25 : (0.25 - timeOfDay) / 0.25;
      ctx.globalAlpha = alpha;
      for (let i = 0; i < 120; i++) {
        const sx = ((i * 137 + 17) % this.W);
        const sy = ((i * 97 + 31) % (this.H * 0.6));
        ctx.fillRect(sx, sy, 1.5, 1.5);
      }
      ctx.globalAlpha = 1;
    }

    // Sun or moon
    if (timeOfDay > 0.15 && timeOfDay < 0.85) {
      // sun
      const t2 = (timeOfDay - 0.15) / 0.7;
      const sx  = this.W * t2;
      const sy  = this.H * 0.1 + Math.sin(t2 * Math.PI) * -this.H * 0.35;
      ctx.fillStyle = '#ffe060';
      ctx.beginPath(); ctx.arc(sx, sy, 28, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff8c0';
      ctx.beginPath(); ctx.arc(sx, sy, 22, 0, Math.PI * 2); ctx.fill();
    } else {
      ctx.fillStyle = '#e0e8ff';
      ctx.beginPath(); ctx.arc(this.W * 0.85, this.H * 0.1, 20, 0, Math.PI * 2); ctx.fill();
    }

    // ── Visible tile range ──────────────────────────
    const tx0 = Math.max(0, Math.floor(this.camX / ts) - 1);
    const ty0 = Math.max(0, Math.floor(this.camY / ts) - 1);
    const tx1 = Math.min(WORLD_W - 1, tx0 + Math.ceil(this.W / ts) + 2);
    const ty1 = Math.min(WORLD_H - 1, ty0 + Math.ceil(this.H / ts) + 2);

    // ── Background (cave darkness) ───────────────────
    const pTy = Math.floor(player.cy / TILE);
    if (pTy > SEA_LEVEL + 10) {
      const depth = Math.min((pTy - SEA_LEVEL - 10) / 40, 1);
      ctx.fillStyle = `rgba(0,0,0,${depth * 0.7})`;
      ctx.fillRect(0, 0, this.W, this.H);
    }

    // ── TILES ───────────────────────────────────────
    for (let ty = ty0; ty <= ty1; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) {
        const t = this.world.get(tx, ty);
        if (t === T.AIR) continue;
        const def = TILE_DEF[t];
        if (!def || !def.color) continue;
        const sx = tx * ts - this.camX, sy = ty * ts - this.camY;

        ctx.fillStyle = def.color;
        ctx.fillRect(sx, sy, ts, ts);

        // Subtle border for solid blocks
        if (def.solid) {
          ctx.strokeStyle = 'rgba(0,0,0,0.25)';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(sx + 0.5, sy + 0.5, ts - 1, ts - 1);
        }

        // Special rendering
        if (t === T.TORCH) {
          // flame
          ctx.fillStyle = '#f0c040';
          ctx.fillRect(sx + ts*0.35, sy + ts*0.1, ts*0.3, ts*0.5);
          ctx.fillStyle = '#ff6000';
          ctx.fillRect(sx + ts*0.42, sy + ts*0.05, ts*0.16, ts*0.25);
          // light glow
          const grd = ctx.createRadialGradient(sx+ts/2, sy+ts/2, 0, sx+ts/2, sy+ts/2, ts*3);
          grd.addColorStop(0, 'rgba(255,200,60,0.18)');
          grd.addColorStop(1, 'rgba(255,200,60,0)');
          ctx.fillStyle = grd;
          ctx.fillRect(sx - ts*2.5, sy - ts*2.5, ts*6, ts*6);
        }

        if (t === T.GRASS) {
          ctx.fillStyle = '#5aaa5a';
          ctx.fillRect(sx, sy, ts, ts * 0.3);
        }
        if (t === T.SUNFLOWER) {
          ctx.fillStyle = '#f0d000';
          ctx.beginPath(); ctx.arc(sx+ts/2, sy+ts/2, ts*0.4, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = '#3a3a00';
          ctx.beginPath(); ctx.arc(sx+ts/2, sy+ts/2, ts*0.2, 0, Math.PI*2); ctx.fill();
        }
        if (t === T.MUSHROOM) {
          ctx.fillStyle = '#e07040';
          ctx.beginPath(); ctx.arc(sx+ts/2, sy+ts*0.3, ts*0.45, Math.PI, Math.PI*2); ctx.fill();
          ctx.fillStyle = '#ddd';
          ctx.fillRect(sx+ts*0.4, sy+ts*0.3, ts*0.2, ts*0.5);
        }
        if (t === T.CHEST) {
          ctx.fillStyle = '#c87020';
          ctx.fillRect(sx+ts*0.1, sy+ts*0.1, ts*0.8, ts*0.8);
          ctx.fillStyle = '#ffa020';
          ctx.fillRect(sx+ts*0.3, sy+ts*0.4, ts*0.4, ts*0.15);
          ctx.fillStyle = '#d4a020';
          ctx.fillRect(sx+ts*0.45, sy+ts*0.43, ts*0.1, ts*0.09);
        }
        if (t === T.WATER) {
          ctx.fillStyle = '#2060c055';
          ctx.fillRect(sx, sy, ts, ts);
          ctx.fillStyle = '#60a0ff22';
          ctx.fillRect(sx, sy, ts, ts*0.2);
        }
        if (t === T.LAVA) {
          const flicker = 0.7 + Math.sin(Date.now() / 200 + tx) * 0.3;
          ctx.fillStyle = `rgba(220,60,0,${flicker * 0.9})`;
          ctx.fillRect(sx, sy, ts, ts);
        }
      }
    }

    // ── Mining overlay ───────────────────────────────
    if (miningTile && miningProgress > 0) {
      const { tx, ty } = miningTile;
      const sx = tx * ts - this.camX, sy = ty * ts - this.camY;
      ctx.fillStyle = `rgba(255,255,255,${miningProgress * 0.4})`;
      ctx.fillRect(sx, sy, ts, ts);
      // crack lines
      ctx.strokeStyle = `rgba(0,0,0,${miningProgress * 0.8})`;
      ctx.lineWidth = 1.5;
      const cracks = Math.floor(miningProgress * 5);
      for (let c = 0; c < cracks; c++) {
        ctx.beginPath();
        ctx.moveTo(sx + ts * (0.3 + c * 0.1), sy + ts * 0.2);
        ctx.lineTo(sx + ts * (0.5 + c * 0.08), sy + ts * 0.8);
        ctx.stroke();
      }
    }

    // ── Block highlight ──────────────────────────────
    if (mouseScreen) {
      const mw = this.screenToWorld(mouseScreen.x, mouseScreen.y);
      const mtx = Math.floor(mw.x / TILE), mty = Math.floor(mw.y / TILE);
      const dist = Math.hypot(mtx - player.tileX, mty - player.tileY);
      if (dist <= 6) {
        const sx = mtx * ts - this.camX, sy = mty * ts - this.camY;
        ctx.strokeStyle = 'rgba(255,255,255,0.6)';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(sx, sy, ts, ts);
      }
    }

    // ── Drops ────────────────────────────────────────
    for (const d of this.world.drops) {
      const { sx, sy } = this.worldToScreen(d.x, d.y);
      const def = ITEM_DEF[d.item];
      const emoji = def ? def.emoji : '?';
      ctx.font = `${ts * 0.7}px serif`;
      ctx.textAlign = 'center';
      ctx.fillText(emoji, sx, sy);
      // bounce anim
    }

    // ── Enemies ──────────────────────────────────────
    for (const e of enemies) {
      const { sx, sy } = this.worldToScreen(e.x, e.y);
      const ets = e.w * this.zoom, eth = e.h * this.zoom;

      ctx.fillStyle = e.hitFlash > 0 ? '#ffffff' : e.color;
      ctx.fillRect(sx, sy, ets, eth);

      // Eyes
      ctx.fillStyle = e.eyeColor;
      ctx.fillRect(sx + ets*0.25, sy + eth*0.25, ets*0.2, eth*0.2);
      ctx.fillRect(sx + ets*0.55, sy + eth*0.25, ets*0.2, eth*0.2);

      // HP bar
      const hpPct = e.hp / e.maxHp;
      ctx.fillStyle = '#300';
      ctx.fillRect(sx, sy - 6, ets, 4);
      ctx.fillStyle = hpPct > 0.5 ? '#0f0' : hpPct > 0.25 ? '#ff0' : '#f00';
      ctx.fillRect(sx, sy - 6, ets * hpPct, 4);
    }

    // ── Player ───────────────────────────────────────
    const { sx: px, sy: py } = this.worldToScreen(player.x, player.y);
    const pw = TILE_DEF ? 14 * this.zoom : 14 * this.zoom; // use player dims
    const ph = 28 * this.zoom;

    // Body
    ctx.fillStyle = '#c8a060';
    ctx.fillRect(px + pw*0.15, py, pw * 0.7, ph * 0.4); // head
    ctx.fillStyle = '#4060a0';
    ctx.fillRect(px + pw*0.1, py + ph*0.4, pw*0.8, ph*0.45); // torso
    ctx.fillStyle = '#303090';
    ctx.fillRect(px + pw*0.1, py + ph*0.85, pw*0.35, ph*0.15); // legs
    ctx.fillRect(px + pw*0.55, py + ph*0.85, pw*0.35, ph*0.15);
    // Eyes
    ctx.fillStyle = '#fff';
    const eyeX = player.dir > 0 ? px + pw*0.55 : px + pw*0.2;
    ctx.fillRect(eyeX, py + ph*0.1, pw*0.18, ph*0.12);
    ctx.fillStyle = '#333';
    ctx.fillRect(eyeX + pw*0.05, py + ph*0.12, pw*0.08, ph*0.08);

    // Tool swing
    const sel = player.selectedItem();
    if (sel) {
      const def = ITEM_DEF[sel.item];
      if (def && def.emoji) {
        ctx.save();
        ctx.font = `${pw}px serif`;
        ctx.textAlign = 'center';
        const toolX = px + pw * (player.dir > 0 ? 1.2 : -0.2);
        const swing = player.attackCooldown > 0 ? Math.sin((1 - player.attackCooldown/20) * Math.PI) * 20 : 0;
        ctx.translate(toolX, py + ph * 0.5);
        ctx.rotate((swing * player.dir) * Math.PI / 180);
        ctx.fillText(def.emoji, 0, 0);
        ctx.restore();
      }
    }

    // ── Particles ────────────────────────────────────
    for (const p of particles) {
      const { sx, sy } = this.worldToScreen(p.x, p.y);
      ctx.globalAlpha = p.life / p.maxLife;
      ctx.fillStyle = p.color;
      ctx.fillRect(sx - p.size/2, sy - p.size/2, p.size, p.size);
    }
    ctx.globalAlpha = 1;

    ctx.restore();
  }

  _skyGradient(t) {
    if (t > 0.25 && t < 0.75) return SKY_COLORS.day;
    if (t >= 0.2 && t <= 0.3)  return SKY_COLORS.dawn;
    if (t >= 0.7 && t <= 0.8)  return SKY_COLORS.dusk;
    return SKY_COLORS.night;
  }
}
