import { T, WORLD_W, WORLD_H, SEA_LEVEL, CAVE_START, HELL_START } from './constants.js';

// ── SIMPLE NOISE ───────────────────────────────────────
function mulberry32(a) {
  return function() {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

class PerlinNoise {
  constructor(seed) {
    this.rand = mulberry32(seed);
    this.perm = Array.from({ length: 512 }, (_, i) => i % 256);
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(this.rand() * (i + 1));
      [this.perm[i], this.perm[j]] = [this.perm[j], this.perm[i]];
    }
    for (let i = 0; i < 256; i++) this.perm[i + 256] = this.perm[i];
  }
  fade(t) { return t * t * t * (t * (t * 6 - 15) + 10); }
  lerp(a, b, t) { return a + t * (b - a); }
  grad(hash, x, y) {
    const h = hash & 3;
    const u = h < 2 ? x : y, v = h < 2 ? y : x;
    return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
  }
  noise(x, y) {
    const xi = Math.floor(x) & 255, yi = Math.floor(y) & 255;
    const xf = x - Math.floor(x), yf = y - Math.floor(y);
    const u = this.fade(xf), v = this.fade(yf);
    const a  = this.perm[xi] + yi, aa = this.perm[a], ab = this.perm[a + 1];
    const b  = this.perm[xi + 1] + yi, ba = this.perm[b], bb = this.perm[b + 1];
    return this.lerp(
      this.lerp(this.grad(this.perm[aa], xf, yf),     this.grad(this.perm[ba], xf - 1, yf),   u),
      this.lerp(this.grad(this.perm[ab], xf, yf - 1), this.grad(this.perm[bb], xf - 1, yf - 1), u),
      v
    );
  }
  octave(x, y, octs = 4, pers = 0.5, lac = 2) {
    let val = 0, amp = 1, freq = 1, max = 0;
    for (let i = 0; i < octs; i++) {
      val += this.noise(x * freq, y * freq) * amp;
      max += amp; amp *= pers; freq *= lac;
    }
    return val / max;
  }
}

// ── WORLD CLASS ────────────────────────────────────────
export class World {
  constructor(seed = Math.random() * 99999 | 0) {
    this.seed  = seed;
    this.tiles = new Uint8Array(WORLD_W * WORLD_H);
    this.drops = []; // { x, y, vx, vy, item, qty }
    this._generate();
  }

  idx(x, y) { return y * WORLD_W + x; }
  get(x, y)  {
    if (x < 0 || x >= WORLD_W || y < 0 || y >= WORLD_H) return T.STONE;
    return this.tiles[this.idx(x, y)];
  }
  set(x, y, t) {
    if (x < 0 || x >= WORLD_W || y < 0 || y >= WORLD_H) return;
    this.tiles[this.idx(x, y)] = t;
  }

  _generate() {
    const noise  = new PerlinNoise(this.seed);
    const noise2 = new PerlinNoise(this.seed + 1337);
    const noise3 = new PerlinNoise(this.seed + 2674);

    // ── Surface heights ──────────────────────────────
    const surface = new Int32Array(WORLD_W);
    for (let x = 0; x < WORLD_W; x++) {
      const n = noise.octave(x / 60, 0, 5, 0.5, 2);
      surface[x] = SEA_LEVEL + Math.floor(n * 18);
    }

    // ── Biome map (0=normal,1=desert,2=snow,3=sky) ──
    const biome = new Uint8Array(WORLD_W);
    // desert: right quarter, snow: left quarter
    for (let x = 0; x < WORLD_W; x++) {
      if (x < 60) biome[x] = 2; // snow
      else if (x > WORLD_W - 80) biome[x] = 1; // desert
      else biome[x] = 0;
    }

    // ── Fill tiles ───────────────────────────────────
    for (let x = 0; x < WORLD_W; x++) {
      const surf = surface[x];
      for (let y = 0; y < WORLD_H; y++) {
        let tile = T.AIR;
        if (y === surf) {
          tile = biome[x] === 2 ? T.SNOW : (biome[x] === 1 ? T.SAND : T.GRASS);
        } else if (y > surf && y < surf + 4) {
          tile = biome[x] === 2 ? T.SNOW : (biome[x] === 1 ? T.SAND : T.DIRT);
        } else if (y >= surf + 4 && y < HELL_START) {
          tile = T.STONE;
        } else if (y >= HELL_START) {
          tile = T.HELLSTONE;
        }
        this.set(x, y, tile);
      }
    }

    // ── Caves ────────────────────────────────────────
    for (let x = 0; x < WORLD_W; x++) {
      for (let y = CAVE_START; y < WORLD_H - 5; y++) {
        const n = noise2.octave(x / 18, y / 18, 3, 0.6, 2);
        if (n > 0.18) this.set(x, y, T.AIR);
      }
    }

    // ── Ore veins ────────────────────────────────────
    const ores = [
      { tile: T.COAL,    minY: surf => surf + 10, maxY: 130, prob: 0.025 },
      { tile: T.IRON,    minY: surf => surf + 20, maxY: 140, prob: 0.018 },
      { tile: T.GOLD,    minY: surf => 80,        maxY: 155, prob: 0.012 },
      { tile: T.DIAMOND, minY: surf => 110,       maxY: HELL_START - 5, prob: 0.006 },
    ];
    for (const { tile, minY, maxY, prob } of ores) {
      for (let x = 0; x < WORLD_W; x++) {
        for (let y = minY(surface[x]); y < maxY; y++) {
          if (this.get(x, y) === T.STONE) {
            const n = Math.abs(noise3.octave(x / 8 + tile, y / 8 + tile, 2, 0.5, 2));
            if (n > 1 - prob * 40) this.set(x, y, tile);
          }
        }
      }
    }

    // ── Trees ─────────────────────────────────────────
    for (let x = 4; x < WORLD_W - 4; x += 5 + (noise.noise(x, 99) * 3 | 0)) {
      if (biome[x] !== 0) continue;
      const s = surface[x];
      if (this.get(x, s) !== T.GRASS) continue;
      const h = 5 + (Math.abs(noise.noise(x * 0.3, 0)) * 4 | 0);
      for (let j = 1; j <= h; j++) this.set(x, s - j, T.WOOD);
      // leaves
      for (let dy = -3; dy <= 0; dy++) {
        for (let dx = -3; dx <= 3; dx++) {
          const d = Math.abs(dx) + Math.abs(dy);
          if (d <= 3 && this.get(x + dx, s - h + dy) === T.AIR)
            this.set(x + dx, s - h + dy, T.LEAF);
        }
      }
    }

    // ── Cacti ────────────────────────────────────────
    for (let x = 3; x < WORLD_W - 3; x += 6 + (Math.abs(noise.noise(x, 77)) * 4 | 0)) {
      if (biome[x] !== 1) continue;
      const s = surface[x];
      if (this.get(x, s) !== T.SAND) continue;
      const h = 2 + (Math.abs(noise.noise(x * 0.5, 5)) * 2 | 0);
      for (let j = 1; j <= h; j++) this.set(x, s - j, T.CACTUS);
    }

    // ── Surface decorations ───────────────────────────
    for (let x = 1; x < WORLD_W - 1; x++) {
      const s = surface[x];
      if (this.get(x, s) === T.GRASS && this.get(x, s - 1) === T.AIR) {
        const r = noise.noise(x * 1.3, 44);
        if (r > 0.6) this.set(x, s - 1, T.SUNFLOWER);
        else if (r < -0.6 && biome[x] === 0) this.set(x, s - 1, T.MUSHROOM);
      }
    }

    // ── Sky islands ───────────────────────────────────
    const skyY = 15;
    for (let cx = 60; cx < WORLD_W - 60; cx += 80 + (Math.abs(noise.noise(cx, 0)) * 20 | 0)) {
      const w = 20 + (Math.abs(noise.noise(cx, 1)) * 10 | 0);
      for (let dx = -w; dx <= w; dx++) {
        const h2 = Math.max(1, Math.floor((1 - (dx * dx) / (w * w)) * 5));
        for (let dy = 0; dy < h2; dy++) {
          this.set(cx + dx, skyY + dy, dy === 0 ? T.CLOUD : T.CLOUD);
        }
        this.set(cx + dx, skyY, T.GRASS);
      }
    }

    // ── Torches in caves ──────────────────────────────
    for (let x = 10; x < WORLD_W - 10; x += 20 + (Math.abs(noise.noise(x, 7)) * 15 | 0)) {
      for (let y = CAVE_START + 5; y < HELL_START - 5; y++) {
        if (this.get(x, y) === T.AIR && this.get(x, y + 1) !== T.AIR) {
          this.set(x, y, T.TORCH);
          break;
        }
      }
    }

    this._surfaceCache = surface;
  }

  spawnX() { return Math.floor(WORLD_W / 2); }
  spawnY() {
    const x = this.spawnX();
    for (let y = 0; y < WORLD_H; y++) {
      if (this.get(x, y) !== T.AIR) return y - 2;
    }
    return SEA_LEVEL - 2;
  }

  // Drop an item into the world
  dropItem(tx, ty, itemId, qty = 1) {
    this.drops.push({
      x: (tx + 0.5) * 16, y: ty * 16,
      vx: (Math.random() - 0.5) * 2, vy: -3,
      item: itemId, qty,
      age: 0,
    });
  }

  updateDrops(dt) {
    for (const d of this.drops) {
      d.vy = Math.min(d.vy + 0.3, 8);
      d.x += d.vx; d.y += d.vy;
      const tx = Math.floor(d.x / 16), ty = Math.floor(d.y / 16);
      const below = this.get(tx, ty + 1);
      if (below !== T.AIR && below !== T.TORCH && below !== T.WATER && below !== T.LAVA) {
        d.vy = 0; d.vx *= 0.8;
      }
      d.age++;
    }
    // remove very old drops (5min)
    this.drops = this.drops.filter(d => d.age < 18000);
  }
}
